(() => {
  // src/shared/sites.js
  var SITES = Object.freeze([
    { id: "chatgpt", label: "ChatGPT", origin: "https://chatgpt.com", startUrl: "https://chatgpt.com/" },
    { id: "claude", label: "Claude", origin: "https://claude.ai", startUrl: "https://claude.ai/new" },
    { id: "gemini", label: "Gemini", origin: "https://gemini.google.com", startUrl: "https://gemini.google.com/app" }
  ]);
  function siteById(id) {
    return SITES.find((site) => site.id === id) || null;
  }

  // src/background.js
  chrome.action.onClicked.addListener(async (tab) => {
    let status = "not-connected";
    let site = null;
    if (tab.id !== void 0) {
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { type: "promptprivacy:status" });
        if (["editor-found", "editor-not-found"].includes(response?.status) && siteById(response?.site)) {
          status = response.status;
          site = response.site;
        }
      } catch {
      }
    }
    chrome.tabs.create({ url: chrome.runtime.getURL(`scanner/index.html?live=${status}${site ? `&site=${site}` : ""}`) });
  });
})();
