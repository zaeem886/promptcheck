(() => {
  // src/shared/sites.js
  var SITES = Object.freeze([
    { id: "chatgpt", label: "ChatGPT", origin: "https://chatgpt.com", startUrl: "https://chatgpt.com/" },
    { id: "claude", label: "Claude", origin: "https://claude.ai", startUrl: "https://claude.ai/new" },
    { id: "gemini", label: "Gemini", origin: "https://gemini.google.com", startUrl: "https://gemini.google.com/app" }
  ]);
  function siteById(id) {
    return SITES.find((site) => site.id === id) || null;
  }
  function siteForOrigin(origin) {
    return SITES.find((site) => site.origin === origin) || null;
  }

  // src/ml/protocol.js
  var MODEL_PAGE = "ml/offscreen.html";
  var PREPARE_MODEL = "promptprivacy:prepare-model";
  function isModelClient(sender) {
    if (sender?.id !== chrome.runtime.id || !sender.url || sender.frameId !== 0) return false;
    const url = new URL(sender.url);
    return !!siteForOrigin(url.origin) || url.protocol === "chrome-extension:" && url.hostname === chrome.runtime.id && url.pathname === "/scanner/index.html";
  }

  // src/background.js
  var preparingModelPage;
  async function prepareModelPage() {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [chrome.runtime.getURL(MODEL_PAGE)]
    });
    if (!contexts.length) await chrome.offscreen.createDocument({
      url: MODEL_PAGE,
      reasons: ["WORKERS"],
      justification: "Run and reuse the local privacy model in a worker for draft, paste, and document checks."
    });
  }
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (message?.type !== PREPARE_MODEL || !isModelClient(sender)) return;
    preparingModelPage ??= prepareModelPage().finally(() => {
      preparingModelPage = null;
    });
    preparingModelPage.then(() => respond({ ready: true }), () => respond({ ready: false }));
    return true;
  });
  chrome.action.onClicked.addListener(async (tab) => {
    let status = "not-connected";
    let site = null;
    if (tab.id !== void 0) {
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { type: "promptprivacy:status" });
        if (["editor-found", "editor-not-found"].includes(response?.status) && siteById(response?.site)) {
          status = response.status;
          site = response.site;
        }
      } catch {
      }
    }
    chrome.tabs.create({ url: chrome.runtime.getURL(`scanner/index.html?live=${status}${site ? `&site=${site}` : ""}`) });
  });
})();
