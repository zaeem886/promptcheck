// src/shared/limits.js
var DEFAULT_LIMITS = Object.freeze({
  maxBytes: 10 * 1024 * 1024,
  timeoutMs: 15e3,
  maxTextChars: 2e6,
  maxPages: 200
});

// src/shared/sites.js
var SITES = Object.freeze([
  { id: "chatgpt", label: "ChatGPT", origin: "https://chatgpt.com", startUrl: "https://chatgpt.com/" },
  { id: "claude", label: "Claude", origin: "https://claude.ai", startUrl: "https://claude.ai/new" },
  { id: "gemini", label: "Gemini", origin: "https://gemini.google.com", startUrl: "https://gemini.google.com/app" }
]);
function siteForOrigin(origin) {
  return SITES.find((site) => site.origin === origin) || null;
}

// src/ml/protocol.js
var MODEL_PORT = "promptprivacy:scan-model";
function isModelClient(sender) {
  if (sender?.id !== chrome.runtime.id || !sender.url || sender.frameId !== 0) return false;
  const url = new URL(sender.url);
  return !!siteForOrigin(url.origin) || url.protocol === "chrome-extension:" && url.hostname === chrome.runtime.id && url.pathname === "/scanner/index.html";
}

// src/ml/offscreen.js
var worker;
var nextId = 0;
var pending = /* @__PURE__ */ new Map();
function getWorker() {
  if (worker) return worker;
  worker = new Worker(new URL("worker.js", import.meta.url), { type: "module" });
  worker.onmessage = ({ data: { id, findings } }) => pending.get(id)?.(findings);
  worker.onerror = (event) => {
    event.preventDefault();
    worker.terminate();
    worker = null;
    for (const finish of pending.values()) finish(null);
  };
  return worker;
}
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== MODEL_PORT) return;
  if (!isModelClient(port.sender)) {
    port.disconnect();
    return;
  }
  const id = ++nextId;
  function finish(findings) {
    pending.delete(id);
    try {
      port.postMessage({ findings });
    } catch {
    }
  }
  port.onDisconnect.addListener(() => {
    if (pending.delete(id)) worker?.postMessage({ id });
  });
  port.onMessage.addListener(function start(message) {
    port.onMessage.removeListener(start);
    const text = message?.text;
    if (typeof text !== "string" || !text.length || text.length > DEFAULT_LIMITS.maxTextChars) {
      finish(null);
      return;
    }
    try {
      pending.set(id, finish);
      getWorker().postMessage({ id, text });
    } catch {
      finish(null);
    }
  });
});
