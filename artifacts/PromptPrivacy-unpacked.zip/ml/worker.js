// src/ml/worker.js
import * as ort from "../vendor/onnxruntime/ort.wasm.min.mjs";

// src/ml/character-model.js
function createCharacterModel(config, runWindow) {
  const { core, halo, tags, min_span_score: cutoff } = config;
  const groups = config.shape_groups.slice(0, -1).map((name) => new RegExp("\\p{" + name + "}", "u"));
  const bucketSize = config.buckets / config.shape_groups.length;
  return async function predict(text, signal) {
    const ids = new Int32Array(text.length);
    const offsets = new Uint32Array(text.length + 1);
    let length = 0;
    let offset = 0;
    for (const character of text) {
      const point = character.codePointAt(0);
      offsets[length] = offset;
      if (point < 128) {
        ids[length] = point + 1;
      } else {
        const group = groups.findIndex((pattern) => pattern.test(character));
        ids[length] = 129 + (group === -1 ? groups.length : group) * bucketSize + point % bucketSize;
      }
      length++;
      offset += character.length;
    }
    offsets[length] = offset;
    const spans = [];
    let label = null;
    let begin = 0;
    let confidence = 0;
    for (let start = 0; start < length; start += core) {
      signal.throwIfAborted();
      const end = Math.min(length, start + core);
      const left = Math.max(0, start - halo);
      const right = Math.min(length, end + halo);
      const logits = await runWindow(ids.subarray(left, right), signal);
      for (let index = start; index < end; index++) {
        const base = (index - left) * tags.length;
        let best = 0;
        for (let tag = 1; tag < tags.length; tag++) {
          if (logits[base + tag] > logits[base + best]) best = tag;
        }
        if (label === null || tags[best] !== "I-" + label) {
          if (label !== null && confidence / (index - begin) >= cutoff) {
            spans.push({ label, start: offsets[begin], end: offsets[index] });
          }
          label = best === 0 ? null : tags[best].slice(2);
          begin = index;
          confidence = 0;
        }
        if (label !== null) {
          let sum = 0;
          for (let tag = 0; tag < tags.length; tag++) sum += Math.exp(logits[base + tag] - logits[base + best]);
          confidence += 1 / sum;
        }
      }
      if (start % (8 * core) === 7 * core) await new Promise((resolve) => setTimeout(resolve, 0));
    }
    signal.throwIfAborted();
    if (label !== null && confidence / (length - begin) >= cutoff) {
      spans.push({ label, start: offsets[begin], end: offsets[length] });
    }
    return spans;
  };
}

// src/shared/locations.js
function locateFindings(text, findings) {
  if (!findings.length) return [];
  const starts = [0];
  for (const match of text.matchAll(/\r\n|[\n\r\u2028\u2029]/g)) starts.push(match.index + match[0].length);
  function position(offset) {
    let low = 0, high = starts.length;
    while (low + 1 < high) {
      const middle = Math.floor((low + high) / 2);
      if (starts[middle] <= offset) low = middle;
      else high = middle;
    }
    return { line: low + 1, column: offset - starts[low] + 1 };
  }
  return findings.map((finding) => {
    const first = position(finding.start), last = position(Math.max(finding.start, finding.end - 1));
    return { ...finding, location: {
      line: first.line,
      column: first.column,
      endLine: last.line,
      endColumn: last.column,
      section: ["Top", "Middle", "Bottom"][Math.min(2, Math.floor(finding.start * 3 / Math.max(1, text.length)))]
    } };
  });
}

// src/shared/hybrid.js
var MODEL_CATEGORIES = Object.freeze({
  PERSON: "person",
  ADDRESS: "address",
  PHONE: "phone",
  EMAIL: "email",
  NATIONAL_ID: "nationalId",
  PASSPORT: "passport",
  BANK_ACCOUNT: "bankAccount",
  IBAN: "iban",
  PAYMENT_CARD: "paymentCard",
  API_KEY: "apiKey",
  PASSWORD: "password",
  PIN: "pin"
});
function maskModelFindings(text, spans) {
  return locateFindings(text, spans.map(({ label, start, end }) => ({
    category: MODEL_CATEGORIES[label],
    start,
    end,
    preview: "[value hidden]",
    source: "ml"
  })));
}

// src/ml/worker.js
ort.env.wasm.numThreads = 1;
ort.env.wasm.proxy = false;
ort.env.wasm.wasmPaths = new URL("../vendor/onnxruntime/", import.meta.url).href;
ort.env.logLevel = "fatal";
var model;
var jobs = /* @__PURE__ */ new Map();
async function loadModel() {
  const config = await fetch(new URL("model.json", import.meta.url)).then((response) => response.json());
  const session = await ort.InferenceSession.create(new URL("model.onnx", import.meta.url).href, {
    executionProviders: ["wasm"],
    logSeverityLevel: 4
  });
  let inference = Promise.resolve();
  return createCharacterModel(config, (ids, signal) => {
    const window = inference.then(async () => {
      signal.throwIfAborted();
      const input = new ort.Tensor("int32", ids, [1, ids.length]);
      let logits;
      try {
        ({ logits } = await session.run({ ids: input }));
        return logits.data.slice();
      } finally {
        logits?.dispose();
        input.dispose();
      }
    });
    inference = window.then(() => void 0, () => void 0);
    return window;
  });
}
self.onmessage = async ({ data: { id, text } }) => {
  if (text === void 0) {
    jobs.get(id)?.abort();
    return;
  }
  const controller = new AbortController();
  jobs.set(id, controller);
  try {
    model ??= loadModel().catch((error) => {
      model = null;
      throw error;
    });
    const predict = await model;
    controller.signal.throwIfAborted();
    const spans = await predict(text, controller.signal);
    self.postMessage({ id, findings: maskModelFindings(text, spans) });
  } catch {
    if (!controller.signal.aborted) self.postMessage({ id, findings: null });
  } finally {
    jobs.delete(id);
  }
};
