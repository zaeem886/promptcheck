// src/shared/locations.js
function formatLocation(location2) {
  if (!location2) return "Location unavailable";
  const pages = location2.page ? location2.endPage && location2.endPage !== location2.page ? `Pages ${location2.page}\u2013${location2.endPage} \xB7 ` : `Page ${location2.page} \xB7 ` : "";
  const lines = location2.line === location2.endLine ? `Line ${location2.line}` : `Lines ${location2.line}\u2013${location2.endLine}`;
  return `${pages}${lines}, column ${location2.column} \xB7 ${location2.section}`;
}

// src/shared/sensitive-patterns.js
var fields = [
  ["password", /password|passwd|passphrase|pwd|mot de passe|contraseña|senha|passwort|كلمة المرور|پاس[ \t]*ورڈ|密码|パスワード/, "secret"],
  ["apiKey", /api[ _-]?key|api[ _-]?secret|client[ _-]?secret|access[ _-]?token|refresh[ _-]?token|auth[ _-]?token|secret[ _-]?key|aws[ _-]?secret[ _-]?access[ _-]?key/, "secret"],
  ["sessionToken", /session[ _-]?(?:id|token|cookie)|cookie|authorization/, "secret"],
  ["pin", /(?:atm|card|security)[ _-]?pin|pin(?:[ _-]?(?:code|number))?|cvv2?|cvc2?|card[ _-]?security[ _-]?code|otp|one[ _-]?time[ _-]?(?:password|code)|recovery[ _-]?code|backup[ _-]?code/, "pin"],
  ["paymentCard", /(?:(?:credit|debit|atm|payment)[ _-]?)card[ _-]?(?:number|no\.?)|card[ _-]?pan|银行卡号|رقم البطاقة|کارڈ نمبر/, "card"],
  ["bankAccount", /swift(?:[ _-]?code)?|bic(?:[ _-]?code)?/, "bankcode"],
  ["bankAccount", /(?:bank[ _-]?)?account[ _-]?(?:number|no\.?)|bank[ _-]?account|routing[ _-]?(?:number|no\.?)|sort[ _-]?code|bsb|ifsc|conta bancária|numéro de compte|kontonummer|رقم الحساب|اکاؤنٹ نمبر|银行账号/, "account"],
  ["nationalId", /national[ _-]?(?:id|identification)(?:[ _-]?(?:number|no\.?))?|(?:tax|voter|resident|residence)[ _-]?(?:id|number)|ssn|social[ _-]?security(?:[ _-]?(?:number|no\.?))?|nino|national insurance(?: number)?|aadhaar(?: number)?|aadhar(?: number)?|pan(?: number)?|cpf|cnpj|sin|nie|dni|nif|steuer[ _-]?id|身份证号|رقم الهوية|شناختی نمبر/, "id"],
  ["passport", /passport(?:[ _-]?(?:number|no\.?|id))?|passeport|pasaporte|reisepass|جواز السفر|پاسپورٹ|护照号/, "id"],
  ["driverLicense", /driver'?s?[ _-]?licen[cs]e(?:[ _-]?(?:number|no\.?))?|driving[ _-]?licen[cs]e(?:[ _-]?(?:number|no\.?))?/, "id"],
  ["phone", /phone(?:[ _-]?(?:number|no\.?))?|mobile(?:[ _-]?(?:number|no\.?))?|telephone|tel|whatsapp|fax|téléphone|teléfono|telefon|فون نمبر|رقم الهاتف|电话号码/, "phone"],
  ["person", /(?:full|first|last|given|family)[ _-]?name|patient[ _-]?name|customer[ _-]?name|employee[ _-]?name|my name|nombre completo|nom complet|पूरा नाम|姓名|الاسم|نام/, "person"],
  ["address", /(?:(?:home|postal|mailing|street|residential|shipping|billing)[ _-]?)address|address|domicilio|adresse|anschrift|endereço|住址|住所|العنوان|پتہ/, "address"],
  ["dateOfBirth", /date[ _-]?of[ _-]?birth|birth[ _-]?date|dob|fecha de nacimiento|date de naissance|geburtsdatum|出生日期|تاريخ الميلاد|تاریخ پیدائش/, "date"],
  ["medical", /(?:medical|patient|health|insurance|policy)[ _-]?(?:record[ _-]?)?(?:number|no\.?|id)|diagnosis|medical[ _-]?condition/, "medical"],
  ["location", /(?:gps[ _-]?)?coordinates|latitude|longitude|ip[ _-]?address/, "location"],
  ["cryptoWallet", /(?:crypto|bitcoin|ethereum|eth|btc)[ _-]?(?:wallet|address)|wallet[ _-]?address/, "wallet"]
];
var labels = fields.map(([, label2]) => label2.source).join("|");
var separator = /["']?[ \t]*(?::|=|：|\bis\b|→)[ \t]*/.source;
var nextField = new RegExp("[, \\t]+(?:" + labels + ")" + separator, "iu");

// src/shared/detector.js
function normalizeKeywords(input) {
  return [...new Set((Array.isArray(input) ? input : []).filter((x) => typeof x === "string").map((x) => x.trim().toLowerCase()).filter(Boolean))].slice(0, 100).map((x) => x.slice(0, 100));
}

// src/shared/limits.js
var DEFAULT_LIMITS = Object.freeze({
  maxBytes: 10 * 1024 * 1024,
  timeoutMs: 15e3,
  maxTextChars: 2e6,
  maxPages: 200
});

// src/shared/scan.js
var SUPPORTED = ["txt", "csv", "pdf", "docx"];
function extension(name) {
  return name.toLowerCase().split(".").pop();
}
function preflight(file, limits2 = DEFAULT_LIMITS) {
  if (!SUPPORTED.includes(extension(file.name))) return "Unsupported file type. Choose TXT, CSV, PDF, or DOCX.";
  if (file.size > limits2.maxBytes) return "File exceeds the configured size limit.";
  if (!file.size) return "The file is empty.";
  return null;
}
function notScanned(reason) {
  return { status: "Not scanned", reason, findings: [], groups: [], partial: false };
}
function incompleteModelScan(result, reason) {
  return {
    ...result,
    partial: true,
    status: "Partially scanned",
    reason: [result.reason, reason].filter(Boolean).join(" ")
  };
}

// src/shared/sites.js
var SITES = Object.freeze([
  { id: "chatgpt", label: "ChatGPT", origin: "https://chatgpt.com", startUrl: "https://chatgpt.com/" },
  { id: "claude", label: "Claude", origin: "https://claude.ai", startUrl: "https://claude.ai/new" },
  { id: "gemini", label: "Gemini", origin: "https://gemini.google.com", startUrl: "https://gemini.google.com/app" }
]);
function siteById(id) {
  return SITES.find((site2) => site2.id === id) || null;
}

// src/ml/protocol.js
var PREPARE_MODEL = "promptprivacy:prepare-model";
var MODEL_PORT = "promptprivacy:scan-model";

// src/ml/client.js
function requestModel(text, signal) {
  return new Promise((resolve) => {
    let port;
    let settled = false;
    function finish(findings = null) {
      if (settled) return;
      settled = true;
      signal.removeEventListener("abort", cancel);
      try {
        port?.disconnect();
      } catch {
      }
      text = null;
      resolve(findings);
    }
    function cancel() {
      finish();
    }
    if (signal.aborted) {
      finish();
      return;
    }
    signal.addEventListener("abort", cancel, { once: true });
    Promise.resolve().then(() => {
      if (!settled) return chrome.runtime.sendMessage({ type: PREPARE_MODEL });
    }).then((response) => {
      if (settled) return;
      if (!response?.ready) {
        finish();
        return;
      }
      port = chrome.runtime.connect({ name: MODEL_PORT });
      port.onDisconnect.addListener(() => {
        void chrome.runtime?.lastError;
        finish();
      });
      port.onMessage.addListener((message) => finish(Array.isArray(message?.findings) ? message.findings : null));
      port.postMessage({ text });
      text = null;
    }).catch(cancel);
  });
}

// src/ui/finding-list.js
var sourceLabels = { rules: "Rules", ml: "ML", both: "Rules + ML" };
function appendFindingList(parent, occurrences, label2, { text, onLocate, batchSize = 20, initialCount = batchSize, onReveal } = {}) {
  if (!occurrences?.length) return;
  const doc = parent.ownerDocument;
  const list = doc.createElement("ol");
  list.className = "occurrences";
  list.setAttribute("aria-label", `${label2} occurrences`);
  parent.append(list);
  const more = doc.createElement("button");
  more.type = "button";
  more.className = "more-findings";
  let shown = 0;
  function appendBatch(count) {
    const end = Math.min(shown + count, occurrences.length);
    for (; shown < end; shown++) {
      const occurrence = occurrences[shown];
      const row = doc.createElement("li");
      row.className = "occurrence";
      const preview = doc.createElement(onLocate ? "button" : "span");
      preview.className = "occurrence-preview";
      preview.textContent = text?.slice(occurrence.start, occurrence.end) ?? occurrence.preview;
      const metadata = doc.createElement("div");
      metadata.className = "occurrence-meta";
      const location2 = doc.createElement("span");
      location2.className = "occurrence-location";
      location2.textContent = formatLocation(occurrence.location);
      if (onLocate) {
        preview.type = "button";
        preview.title = `Show in source text \xB7 ${location2.textContent}`;
        preview.onclick = () => onLocate(occurrence);
      }
      const source = doc.createElement("span");
      source.className = "occurrence-source";
      source.textContent = sourceLabels[occurrence.source];
      metadata.append(location2, source);
      row.append(preview, metadata);
      list.append(row);
    }
    const remaining = occurrences.length - shown;
    more.textContent = `Show ${Math.min(batchSize, remaining)} more ${label2} findings (${remaining} remaining)`;
    more.hidden = remaining === 0;
    onReveal?.(shown);
  }
  more.onclick = () => appendBatch(batchSize);
  parent.append(more);
  appendBatch(Math.max(initialCount, batchSize));
}

// src/scanner/app.js
var $ = (id) => document.getElementById(id);
var params = new URLSearchParams(location.search);
var site = siteById(params.get("site"));
var label = site?.label || "AI chat";
var connectionMessages = {
  "editor-found": `Connected: the live scanner found the ${label} prompt editor in the tab where you clicked the toolbar icon. Finding details appear in a separate advisory near the editor.`,
  "editor-not-found": `The ${label} live scanner loaded, but could not find a supported prompt editor. Open a new chat and click the toolbar icon again. If this persists, the ${label} editor adapter needs updating.`,
  "not-connected": "The live scanner is not connected to that tab. Open chatgpt.com, claude.ai, or gemini.google.com, allow PromptPrivacy access to that site in your browser extension settings, and refresh the chat tab after loading or reloading the extension. Then click the toolbar icon from that tab again."
};
var connection = params.get("live");
if (Object.hasOwn(connectionMessages, connection)) {
  $("live-status").hidden = false;
  $("live-title").textContent = `${label} live scanner`;
  $("live-message").textContent = connectionMessages[connection];
}
var worker = null;
var generation = 0;
var deadline = null;
var modelRequest = null;
var keywords = [];
function stop() {
  generation++;
  clearTimeout(deadline);
  modelRequest?.abort();
  modelRequest = null;
  worker?.terminate();
  worker = null;
  $("cancel").disabled = true;
}
function render(result, { duration, checkingModel = false, extractedText } = {}) {
  const box = $("result");
  box.replaceChildren();
  box.dataset.status = checkingModel ? "Scanning" : result.status;
  const title = document.createElement("h3");
  title.textContent = checkingModel && !result.findings.length && !result.partial ? "Checking with ML\u2026" : result.status;
  box.append(title);
  if (checkingModel && title.textContent !== "Checking with ML\u2026") {
    const pending = document.createElement("p");
    pending.textContent = "Checking with ML\u2026";
    box.append(pending);
  }
  if (result.reason) {
    const p = document.createElement("p");
    p.textContent = result.reason;
    box.append(p);
  }
  if (result.partial && result.findings.length) {
    const p = document.createElement("p");
    p.textContent = `${result.findings.length} possible findings so far.`;
    box.append(p);
  }
  for (const group of result.groups) {
    const row = document.createElement("div");
    row.className = "finding";
    row.textContent = `${group.label} \xB7 ${group.count}`;
    appendFindingList(row, group.occurrences, group.label, { text: extractedText });
    box.append(row);
  }
  if (result.findings.length) {
    const note = document.createElement("p");
    note.className = "footnote";
    note.textContent = `Locations refer to ${result.locationBasis}${result.partial ? " in the scanned portion" : ""}. Lines count actual line breaks; Top/Middle/Bottom are thirds of that text. PDF/DOCX visual lines and screen wrapping may differ.`;
    box.append(note);
  }
  if (result.pages) {
    const p = document.createElement("p");
    p.textContent = `${result.scannedPages} of ${result.pages} pages yielded text.`;
    box.append(p);
  }
  if (duration !== void 0) {
    const p = document.createElement("p");
    p.textContent = `Processed locally in ${(duration / 1e3).toFixed(2)} s. Nothing was attached or uploaded.`;
    box.append(p);
  }
}
function limits() {
  const size = Number($("max-size").value), seconds = Number($("timeout").value);
  if (!Number.isFinite(size) || size < 1 || size > 25 || !Number.isFinite(seconds) || seconds < 1 || seconds > 60) return null;
  return { ...DEFAULT_LIMITS, maxBytes: size * 1024 * 1024, timeoutMs: seconds * 1e3 };
}
async function scan(file) {
  stop();
  const id = generation;
  const config = limits();
  if (!config) return render(notScanned("Choose a size limit from 1\u201325 MiB and time limit from 1\u201360 seconds."));
  const reason = preflight(file, config);
  if (reason) return render(notScanned(reason));
  $("result").dataset.status = "Scanning";
  $("result").textContent = "Scanning locally\u2026";
  $("cancel").disabled = false;
  let ruleResult = null, extractedText;
  deadline = setTimeout(() => {
    if (id !== generation) return;
    stop();
    render(ruleResult ? incompleteModelScan(ruleResult, "The ML check reached the time limit. Rule results are shown.") : notScanned("Processing time limit exceeded. The worker was terminated."), { extractedText });
  }, config.timeoutMs);
  try {
    const buffer = await file.arrayBuffer();
    if (id !== generation) return;
    worker = new Worker(new URL("worker.js", import.meta.url), { type: "module" });
    worker.onmessage = ({ data }) => {
      if (id !== generation || data.id !== id) return;
      if (data.modelText === void 0) {
        stop();
        render(data.result, { duration: data.durationMs, extractedText });
        return;
      }
      ruleResult = data.result;
      extractedText = data.modelText;
      modelRequest = new AbortController();
      const pending = requestModel(extractedText, modelRequest.signal);
      render(ruleResult, { checkingModel: true, extractedText });
      pending.then((findings) => {
        if (id === generation) worker.postMessage({ id, findings });
      });
    };
    worker.onerror = (event) => {
      event.preventDefault();
      if (id !== generation) return;
      stop();
      render(ruleResult ? incompleteModelScan(ruleResult, "The ML check could not finish. Rule results are shown.") : notScanned("Document processing failed. No scan result is available."), { extractedText });
    };
    worker.postMessage({ id, buffer, name: file.name, limits: config, keywords }, [buffer]);
  } catch {
    if (id === generation) {
      stop();
      render(notScanned("The selected file could not be read."));
    }
  }
}
$("file").addEventListener("change", () => {
  if ($("file").files[0]) scan($("file").files[0]);
});
$("cancel").onclick = () => {
  stop();
  render(notScanned("Scan cancelled."));
};
$("clear").onclick = () => {
  stop();
  $("file").value = "";
  $("result").removeAttribute("data-status");
  $("result").textContent = "Ready when you are. Select a document. No file is attached or uploaded.";
};
chrome.storage.local.get({ keywords: [] }).then((value) => {
  keywords = normalizeKeywords(value.keywords);
  $("keywords").value = keywords.join("\n");
});
$("save").onclick = async () => {
  const next = normalizeKeywords($("keywords").value.split("\n"));
  try {
    await chrome.storage.local.set({ keywords: next });
    keywords = next;
    $("keywords").value = keywords.join("\n");
    $("saved").textContent = "Keyword preferences saved on this device.";
  } catch {
    $("saved").textContent = "Could not save preferences. Please reload the extension.";
  }
};
window.addEventListener("pagehide", stop);
