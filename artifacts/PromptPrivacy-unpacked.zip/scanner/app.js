// src/shared/detector.js
function normalizeKeywords(input) {
  return [...new Set((Array.isArray(input) ? input : []).filter((x) => typeof x === "string").map((x) => x.trim().toLowerCase()).filter(Boolean))].slice(0, 100).map((x) => x.slice(0, 100));
}

// src/shared/scan.js
var DEFAULT_LIMITS = Object.freeze({ maxBytes: 10 * 1024 * 1024, timeoutMs: 15e3, maxTextChars: 2e6, maxPages: 200 });
var SUPPORTED = ["txt", "csv", "pdf", "docx"];
function extension(name) {
  return name.toLowerCase().split(".").pop();
}
function preflight(file, limits2 = DEFAULT_LIMITS) {
  if (!SUPPORTED.includes(extension(file.name))) return "Unsupported file type. Choose TXT, CSV, PDF, or DOCX.";
  if (file.size > limits2.maxBytes) return "File exceeds the configured size limit.";
  if (!file.size) return "The file is empty.";
  return null;
}
function notScanned(reason) {
  return { status: "Not scanned", reason, findings: [], groups: [], partial: false };
}

// src/shared/sites.js
var SITES = Object.freeze([
  { id: "chatgpt", label: "ChatGPT", origin: "https://chatgpt.com", startUrl: "https://chatgpt.com/" },
  { id: "claude", label: "Claude", origin: "https://claude.ai", startUrl: "https://claude.ai/new" },
  { id: "gemini", label: "Gemini", origin: "https://gemini.google.com", startUrl: "https://gemini.google.com/app" }
]);
function siteById(id) {
  return SITES.find((site2) => site2.id === id) || null;
}

// src/scanner/app.js
var $ = (id) => document.getElementById(id);
var params = new URLSearchParams(location.search);
var site = siteById(params.get("site"));
var label = site?.label || "AI chat";
var connectionMessages = {
  "editor-found": `Connected: the live scanner found the ${label} prompt editor in the tab where you clicked the toolbar icon. Typed text stays unchanged; masked previews appear in a separate advisory near the editor.`,
  "editor-not-found": `The ${label} live scanner loaded, but could not find a supported prompt editor. Open a new chat and click the toolbar icon again. If this persists, the ${label} editor adapter needs updating.`,
  "not-connected": "The live scanner is not connected to that tab. Open chatgpt.com, claude.ai, or gemini.google.com, allow PromptPrivacy access to that site in your browser extension settings, and refresh the chat tab after loading or reloading the extension. Then click the toolbar icon from that tab again."
};
var connection = params.get("live");
if (Object.hasOwn(connectionMessages, connection)) {
  $("live-status").hidden = false;
  $("live-title").textContent = `${label} live scanner`;
  $("live-message").textContent = connectionMessages[connection];
}
var worker = null;
var generation = 0;
var deadline = null;
var keywords = [];
function stop() {
  generation++;
  clearTimeout(deadline);
  worker?.terminate();
  worker = null;
  $("cancel").disabled = true;
}
function render(result, duration) {
  const box = $("result");
  box.replaceChildren();
  box.dataset.status = result.status;
  const title = document.createElement("h3");
  title.textContent = result.status;
  box.append(title);
  if (result.reason) {
    const p = document.createElement("p");
    p.textContent = result.reason;
    box.append(p);
  }
  if (result.partial && result.findings.length) {
    const p = document.createElement("p");
    p.textContent = `${result.findings.length} possible findings in the extracted portion.`;
    box.append(p);
  }
  for (const group of result.groups) {
    const row = document.createElement("div");
    row.className = "finding";
    row.textContent = `${group.label} \xB7 ${group.count}`;
    const preview = document.createElement("span");
    preview.textContent = group.previews.join(" \xB7 ");
    row.append(preview);
    box.append(row);
  }
  if (result.pages) {
    const p = document.createElement("p");
    p.textContent = `${result.scannedPages} of ${result.pages} pages yielded text.`;
    box.append(p);
  }
  if (duration !== void 0) {
    const p = document.createElement("p");
    p.textContent = `Processed locally in ${(duration / 1e3).toFixed(2)} s. Nothing was attached or uploaded.`;
    box.append(p);
  }
}
function limits() {
  const size = Number($("max-size").value), seconds = Number($("timeout").value);
  if (!Number.isFinite(size) || size < 1 || size > 25 || !Number.isFinite(seconds) || seconds < 1 || seconds > 60) return null;
  return { ...DEFAULT_LIMITS, maxBytes: size * 1024 * 1024, timeoutMs: seconds * 1e3 };
}
async function scan(file) {
  stop();
  const id = generation;
  const config = limits();
  if (!config) return render(notScanned("Choose a size limit from 1\u201325 MiB and time limit from 1\u201360 seconds."));
  const reason = preflight(file, config);
  if (reason) return render(notScanned(reason));
  $("result").dataset.status = "Scanning";
  $("result").textContent = "Scanning locally\u2026";
  $("cancel").disabled = false;
  deadline = setTimeout(() => {
    if (id === generation) {
      stop();
      render(notScanned("Processing time limit exceeded. The worker was terminated."));
    }
  }, config.timeoutMs);
  try {
    const buffer = await file.arrayBuffer();
    if (id !== generation) return;
    worker = new Worker(new URL("worker.js", import.meta.url), { type: "module" });
    worker.onmessage = ({ data }) => {
      if (id !== generation || data.id !== id) return;
      stop();
      render(data.result, data.durationMs);
    };
    worker.onerror = (event) => {
      event.preventDefault();
      if (id === generation) {
        stop();
        render(notScanned("Document processing failed. No scan result is available."));
      }
    };
    worker.postMessage({ id, buffer, name: file.name, limits: config, keywords }, [buffer]);
  } catch {
    if (id === generation) {
      stop();
      render(notScanned("The selected file could not be read."));
    }
  }
}
$("file").addEventListener("change", () => {
  if ($("file").files[0]) scan($("file").files[0]);
});
$("cancel").onclick = () => {
  stop();
  render(notScanned("Scan cancelled."));
};
$("clear").onclick = () => {
  stop();
  $("file").value = "";
  $("result").removeAttribute("data-status");
  $("result").textContent = "Ready when you are. Select a document. No file is attached or uploaded.";
};
chrome.storage.local.get({ keywords: [] }).then((value) => {
  keywords = normalizeKeywords(value.keywords);
  $("keywords").value = keywords.join("\n");
});
$("save").onclick = async () => {
  const next = normalizeKeywords($("keywords").value.split("\n"));
  try {
    await chrome.storage.local.set({ keywords: next });
    keywords = next;
    $("keywords").value = keywords.join("\n");
    $("saved").textContent = "Keyword preferences saved on this device.";
  } catch {
    $("saved").textContent = "Could not save preferences. Please reload the extension.";
  }
};
window.addEventListener("pagehide", stop);
