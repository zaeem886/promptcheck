(() => {
  // src/content/adapters/chatgpt.js
  var chatgpt_default = {
    id: "chatgpt",
    selectors: [
      '#prompt-textarea[contenteditable="true"]',
      "textarea#prompt-textarea",
      '[contenteditable="true"][data-testid="prompt-textarea"]',
      '[contenteditable="true"][role="textbox"][data-composer-markdown]'
    ],
    composerSelector: "form",
    sendSelector: 'button[data-testid="send-button"], button[data-testid="composer-send-button"], button[aria-label="Send prompt"], button[aria-label="Send message"], button[type="submit"]',
    stopSelector: 'button[data-testid="stop-button"], button[aria-label="Stop generating"], button[aria-label="Stop response"]',
    excludeSelector: '[data-message-author-role], [data-testid="conversation-turn"], article, [role="log"], [role="dialog"]'
  };

  // src/content/adapters/claude.js
  var claude_default = {
    id: "claude",
    // Explicit chat-input markers first. Older Claude composers use ProseMirror
    // without an id/role; the fallback excludes messages, dialogs, and artifacts.
    selectors: [
      '[data-testid="chat-input"][contenteditable="true"]',
      '[data-testid="chat-input"] .ProseMirror[contenteditable="true"]',
      'textarea[data-testid="chat-input"]',
      '.ProseMirror[contenteditable="true"][aria-label*="Claude" i]',
      'fieldset .ProseMirror[contenteditable="true"]',
      '.ProseMirror[contenteditable="true"]'
    ],
    composerSelector: "fieldset, form",
    sendSelector: 'button[aria-label="Send message"], button[aria-label="Send Message"], button[data-testid="send-button"], button[type="submit"]',
    stopSelector: 'button[aria-label="Stop response"], button[aria-label="Stop generating"], button[aria-label="Stop Response"], button[data-testid="stop-button"]',
    excludeSelector: '[data-testid="user-message"], [data-testid="assistant-message"], [data-testid="chat-message"], [data-testid="artifact-panel"], [data-testid="artifact"], [data-testid="artifact-view"], [data-message-author-role], article, [role="log"], [role="dialog"]'
  };

  // src/content/adapters/gemini.js
  var gemini_default = {
    id: "gemini",
    // Public Gemini DOM verified with the signed-out development probe. The
    // .ql-clipboard sibling is not a prompt editor and must never be scanned.
    selectors: [
      'rich-textarea .ql-editor[contenteditable="true"][role="textbox"]',
      'rich-textarea [contenteditable="true"][role="textbox"]',
      "rich-textarea textarea"
    ],
    composerSelector: "input-area-v2, input-area, .input-area-container, form",
    sendSelector: 'button.send-button, button[aria-label="Send message"], button[aria-label="Send"], button[type="submit"]',
    stopSelector: 'button.stop-button, button[aria-label="Stop response"], button[aria-label="Stop generating"], button[aria-label="Stop"]',
    excludeSelector: '.ql-clipboard, user-query, model-response, [data-message-author-role], article, [role="log"], [role="dialog"]'
  };

  // src/shared/sites.js
  var SITES = Object.freeze([
    { id: "chatgpt", label: "ChatGPT", origin: "https://chatgpt.com", startUrl: "https://chatgpt.com/" },
    { id: "claude", label: "Claude", origin: "https://claude.ai", startUrl: "https://claude.ai/new" },
    { id: "gemini", label: "Gemini", origin: "https://gemini.google.com", startUrl: "https://gemini.google.com/app" }
  ]);
  function siteForOrigin(origin) {
    return SITES.find((site) => site.origin === origin) || null;
  }

  // src/content/adapters/index.js
  var adapters = [chatgpt_default, claude_default, gemini_default];
  function adapterForOrigin(origin) {
    const site = siteForOrigin(origin);
    return site ? { ...adapters.find((adapter2) => adapter2.id === site.id), ...site } : null;
  }
  function visibleEditor(element, doc) {
    if (!element.getClientRects().length || element.disabled || element.readOnly || element.getAttribute("aria-disabled") === "true") return false;
    if (element.closest('[hidden], [inert], [aria-hidden="true"]')) return false;
    const style = doc.defaultView.getComputedStyle(element);
    return style.visibility !== "hidden" && style.visibility !== "collapse" && style.display !== "none";
  }
  function findEditor(doc, adapter2) {
    for (const selector of adapter2.selectors) {
      const candidates = [...doc.querySelectorAll(selector)].filter((element) => visibleEditor(element, doc) && !element.closest(adapter2.excludeSelector));
      const focused = candidates.find((element) => element === doc.activeElement || element.contains(doc.activeElement));
      if (focused) return focused;
      if (candidates.length === 1) return candidates[0];
      if (candidates.length > 1) return null;
    }
    return null;
  }
  function composerForEditor(doc, editor, adapter2) {
    if (!editor) return null;
    const explicit = editor.closest(adapter2.composerSelector);
    let controlRoot = null;
    for (let node = editor.parentElement, depth = 0; node && depth < 10; node = node.parentElement, depth++) {
      if (node === doc.body || node === doc.documentElement || node.matches('main, [role="main"]')) break;
      if (node.querySelector(`${adapter2.sendSelector}, ${adapter2.stopSelector}`)) {
        controlRoot = node;
        break;
      }
    }
    let root = explicit && (!controlRoot || explicit.contains(controlRoot)) ? explicit : controlRoot;
    if (!root) {
      for (let node = editor.parentElement, depth = 0; node && depth < 6; node = node.parentElement, depth++) {
        if (node === doc.body || node.matches('main, [role="main"]')) break;
        const style = doc.defaultView.getComputedStyle(node);
        if (parseFloat(style.borderRadius) >= 8) {
          root = node;
          break;
        }
      }
    }
    return root || (editor.parentElement === doc.body ? editor : editor.parentElement);
  }
  function enabledSendButton(button, adapter2) {
    return !!button && button.matches(adapter2.sendSelector) && !button.matches(adapter2.stopSelector) && !button.disabled && button.getAttribute("aria-disabled") !== "true" && !button.closest('[hidden], [inert], [aria-hidden="true"]');
  }

  // src/shared/detector.js
  var CATEGORY_NAMES = { email: "Email", phone: "Pakistani phone", cnic: "CNIC-like number", apiKey: "API key format", privateKey: "Private key marker", keyword: "Sensitive keyword" };
  var word = /[\p{L}\p{N}_]/u;
  function bounded(text, start, end) {
    return (!text[start - 1] || !word.test(text[start - 1])) && (!text[end] || !word.test(text[end]));
  }
  function normalizeKeywords(input) {
    return [...new Set((Array.isArray(input) ? input : []).filter((x) => typeof x === "string").map((x) => x.trim().toLowerCase()).filter(Boolean))].slice(0, 100).map((x) => x.slice(0, 100));
  }
  function mask(category, value) {
    if (category === "apiKey" || category === "privateKey") return "[credential hidden]";
    if (category === "keyword") return "[keyword hidden]";
    if (category === "email") return `${value[0]}***@***`;
    return `***${value.replace(/\D/g, "").slice(-2)}`;
  }
  function detect(text, keywords = []) {
    const candidates = [];
    const add = (category, pattern, priority, accept = () => true) => {
      for (const m of text.matchAll(pattern)) {
        const start = m.index, end = start + m[0].length;
        if (bounded(text, start, end) && accept(m, start)) candidates.push({ category, start, end, priority, preview: mask(category, m[0]) });
      }
    };
    add("privateKey", /-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----/g, 0);
    add("apiKey", /(?:sk-proj-[A-Za-z0-9_-]{20,200}|sk-[A-Za-z0-9]{20,100}|ghp_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{22,255}|AKIA[A-Z0-9]{16}|AIza[A-Za-z0-9_-]{35})/g, 1);
    add("email", /[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+/g, 2);
    add("cnic", /[1-7]\d{4}-\d{7}-\d/g, 3);
    add("cnic", /[1-7]\d{12}/g, 3, (_m, start) => /(?:cnic|national\s+id)\s*[:#=-]?\s*$/i.test(text.slice(Math.max(0, start - 35), start)));
    add("phone", /(?:\+92[ -]?3\d{2}[ -]?\d{7}|0092[ -]?3\d{2}[ -]?\d{7}|03\d{2}[ -]?\d{7})/g, 4, (_m, start) => {
      return !/(?:order|invoice|reference|tracking)\s*(?:number|no\.?)?\s*[:#=-]?\s*$/i.test(text.slice(Math.max(0, start - 40), start));
    });
    for (const keyword of normalizeKeywords(keywords)) {
      const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      for (const match of text.matchAll(new RegExp(escaped, "giu"))) {
        candidates.push({ category: "keyword", start: match.index, end: match.index + match[0].length, priority: 5, preview: mask("keyword", keyword) });
      }
    }
    candidates.sort((a, b) => a.priority - b.priority || b.end - b.start - (a.end - a.start) || a.start - b.start);
    const accepted = [];
    const occupied = new Uint8Array(text.length);
    for (const candidate of candidates) {
      let overlaps = false;
      for (let i = candidate.start; i < candidate.end; i++) if (occupied[i]) {
        overlaps = true;
        break;
      }
      if (!overlaps) {
        occupied.fill(1, candidate.start, candidate.end);
        accepted.push(candidate);
      }
    }
    return accepted.sort((a, b) => a.start - b.start).map(({ priority, ...finding }) => finding);
  }
  function summarize(findings) {
    return Object.entries(CATEGORY_NAMES).map(([category, label]) => {
      const group = findings.filter((f) => f.category === category);
      return { category, label, count: group.length, previews: [...new Set(group.map((f) => f.preview))].slice(0, 3) };
    }).filter((x) => x.count);
  }

  // src/shared/scan.js
  var DEFAULT_LIMITS = Object.freeze({ maxBytes: 10 * 1024 * 1024, timeoutMs: 15e3, maxTextChars: 2e6, maxPages: 200 });

  // src/content/advisory.css
  var advisory_default = ":host {\n  all: initial;\n  display: block;\n  position: relative;\n  box-sizing: border-box;\n  width: 100%;\n  min-width: 0;\n  flex: 0 0 100%;\n  grid-column: 1 / -1;\n  clear: both;\n  margin: 8px 0 0;\n  color-scheme: light dark;\n  color: light-dark(#263f3c, #d7e5e0);\n  font: 12px/1.5 system-ui, sans-serif;\n  text-align: left;\n}\n:host([hidden]) { display: none !important; }\n* { box-sizing: border-box; }\nsection { border: 1px solid light-dark(#d4dfd9, #3c5049); border-radius: 12px; background: light-dark(#f7faf8, #17231f); padding: 10px 12px; }\nheader { display: flex; gap: 8px; align-items: center; }\n.brand { font-size: 12px; font-weight: 650; letter-spacing: -.2px; }\n.state { flex: 1; font-size: 11px; color: light-dark(#627268, #a0b7aa); }\n.close { flex: 0 0 28px; width: 28px; height: 28px; border: none; padding: 0; background: transparent; color: inherit; border-radius: 7px; font: 20px/1 system-ui; cursor: pointer; }\n.close:hover { background: light-dark(#e6eee8, #2b3c32); }\n.scope { display: flex; flex-wrap: wrap; gap: 5px; align-items: center; margin-top: 5px; }\n.scope-label { font-size: 11px; color: light-dark(#627268, #a0b7aa); margin-right: 3px; }\n.tag { padding: 2px 7px; border-radius: 5px; font-size: 11px; white-space: nowrap; background: light-dark(#eaf0eb, #293c31); }\ndetails { margin-top: 7px; }\nsummary { cursor: pointer; width: fit-content; font-size: 11px; color: light-dark(#496856, #acc8b6); }\n.detail-scope { margin-top: 8px; padding-top: 7px; border-top: 1px solid light-dark(#e0e7e1, #33483b); }\nstrong { display: block; font-size: 11px; margin-bottom: 3px; }\n.finding { font-size: 11px; overflow-wrap: anywhere; }\np { margin: 5px 0 0; font-size: 11px; color: light-dark(#627268, #a0b7aa); }\n.privacy { font-size: 10px; margin-top: 6px; }\nbutton:focus-visible, summary:focus-visible { outline: 2px solid #b99a5a; outline-offset: 2px; }\n@media(max-width:500px) { header { flex-wrap: wrap; } .state { min-width: 120px; } .close { margin-left: auto; } }\n";

  // src/content/live-scanner.js
  function startLiveScanner(adapter2, doc = document, storage = chrome.storage) {
    let editor = null, composer = null, host = null, panel = null, timer;
    let keywords = [], lastText = null, draftGroups = null, pasteReview = null;
    let suppressedDraft = null, expanded = false, pendingEnter = null, enterTimer;
    const textOf = (element) => element ? ("value" in element ? element.value : element.innerText) || "" : "";
    const read = () => textOf(editor);
    function addText(parent, tag, text, className) {
      const element = doc.createElement(tag);
      element.textContent = text;
      if (className) element.className = className;
      parent.append(element);
      return element;
    }
    function render() {
      if (!panel) return;
      panel.replaceChildren();
      host.hidden = draftGroups === null && !pasteReview;
      if (host.hidden) return;
      const scopes = [];
      if (draftGroups !== null) scopes.push({ label: "Current draft", groups: draftGroups, partial: false });
      if (pasteReview) scopes.push({ label: "Pasted text snapshot", ...pasteReview });
      const hasFindings = scopes.some((scope) => scope.groups.length);
      const partial = scopes.some((scope) => scope.partial);
      const header = doc.createElement("header");
      panel.append(header);
      addText(header, "span", "PromptPrivacy", "brand");
      addText(header, "span", partial ? "Partially scanned" : hasFindings ? "Possible sensitive information" : "No supported patterns found", "state");
      const dismiss = addText(header, "button", "\xD7", "close");
      dismiss.type = "button";
      dismiss.dataset.promptprivacyDismiss = "";
      dismiss.setAttribute("aria-label", "Dismiss warning");
      dismiss.title = "Dismiss until the draft changes or you paste again";
      dismiss.onclick = clearAfterSendOrDismiss;
      for (const scope of scopes) {
        const row = doc.createElement("div");
        row.className = "scope";
        panel.append(row);
        addText(row, "span", scope.label === "Current draft" ? "Draft" : "Last paste", "scope-label");
        for (const group of scope.groups) addText(row, "span", `${group.label} \xB7 ${group.count}`, "tag");
        if (!scope.groups.length) addText(row, "span", scope.partial ? "Limited coverage" : "No supported patterns found", "tag");
      }
      const details = doc.createElement("details");
      panel.append(details);
      details.open = expanded;
      details.ontoggle = () => {
        if (details.isConnected) expanded = details.open;
      };
      addText(details, "summary", "Masked details");
      for (const scope of scopes) {
        const block = doc.createElement("div");
        block.className = "detail-scope";
        details.append(block);
        const status = scope.partial ? "Partially scanned" : scope.groups.length ? scope.label === "Current draft" ? "Possible sensitive information" : "Findings detected" : "No supported patterns found";
        addText(block, "strong", `${scope.label} \xB7 ${status}`);
        for (const group of scope.groups) addText(block, "div", `${group.label}: ${group.count} \xB7 ${group.previews.join(", ")}`, "finding");
        if (scope.partial) addText(block, "p", "Only the first 2,000,000 characters were scanned.");
      }
      if (pasteReview) addText(details, "p", "Last-paste review only. Attachment edits/removal are not tracked. This review clears on an observed send action or when dismissed.");
      addText(panel, "p", `Advisory only. ${adapter2.label} can access your draft. PromptPrivacy cannot verify transmission timing.`, "privacy");
    }
    function clearAfterSendOrDismiss() {
      clearTimeout(timer);
      clearTimeout(enterTimer);
      pendingEnter = null;
      pasteReview = null;
      draftGroups = null;
      expanded = false;
      suppressedDraft = read();
      lastText = suppressedDraft;
      render();
    }
    function queue() {
      const text = read();
      if (text === lastText) return;
      lastText = text;
      clearTimeout(timer);
      draftGroups = null;
      render();
      if (text !== suppressedDraft) suppressedDraft = null;
      if (!text.trim() || text === suppressedDraft) return;
      timer = setTimeout(() => {
        if (!editor?.isConnected || read() !== text) return;
        draftGroups = summarize(detect(text, keywords));
        render();
      }, 300);
    }
    function stopControlPresent(root) {
      return !!root && [...root.querySelectorAll(adapter2.stopSelector)].some((button) => button.getClientRects().length && !button.closest('[hidden], [aria-hidden="true"]'));
    }
    function checkKeyboardSend(active, root) {
      if (!pendingEnter) return;
      const current = textOf(active);
      const clearedText = pendingEnter.text.trim() && !current.trim();
      const startedResponse = !pendingEnter.hadStop && stopControlPresent(root || composer);
      if (clearedText || startedResponse) {
        clearAfterSendOrDismiss();
        return;
      }
      if (current !== pendingEnter.text && current.trim()) {
        clearTimeout(enterTimer);
        pendingEnter = null;
      }
    }
    function onInput() {
      checkKeyboardSend(editor, composer);
      queue();
    }
    function reconcile() {
      const active = findEditor(doc, adapter2);
      const root = composerForEditor(doc, active, adapter2);
      checkKeyboardSend(active, root);
      if (active !== editor || active && !host?.isConnected) {
        editor?.removeEventListener("input", onInput);
        clearTimeout(timer);
        host?.remove();
        editor = active;
        composer = root;
        lastText = null;
        draftGroups = null;
        panel = null;
        if (!editor) return;
        host = doc.createElement("div");
        host.dataset.promptprivacy = "advisory";
        host.hidden = true;
        const shadow = host.attachShadow({ mode: "closed" });
        const style = doc.createElement("style");
        style.textContent = advisory_default;
        panel = doc.createElement("section");
        panel.setAttribute("role", "status");
        panel.setAttribute("aria-live", "polite");
        panel.setAttribute("aria-atomic", "true");
        shadow.append(style, panel);
        composer.after(host);
        editor.addEventListener("input", onInput);
      } else if (editor && (root !== composer || host.previousElementSibling !== root)) {
        composer = root;
        composer.after(host);
      }
      if (editor) queue();
    }
    const observer = new MutationObserver(reconcile);
    observer.observe(doc.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["contenteditable", "id", "class", "style", "data-testid", "data-composer-markdown", "role", "hidden", "inert", "aria-hidden", "aria-disabled", "aria-busy", "aria-label", "disabled", "readonly"]
    });
    doc.addEventListener("focusin", reconcile);
    doc.addEventListener("paste", (event) => {
      reconcile();
      if (!editor || !(event.target === editor || editor.contains(event.target))) return;
      const text = event.clipboardData?.getData("text/plain");
      pasteReview = null;
      suppressedDraft = null;
      pendingEnter = null;
      clearTimeout(enterTimer);
      if (text?.trim()) pasteReview = {
        groups: summarize(detect(text.slice(0, DEFAULT_LIMITS.maxTextChars), keywords)),
        partial: text.length > DEFAULT_LIMITS.maxTextChars
      };
      lastText = null;
      queue();
      render();
    }, { capture: true, passive: true });
    doc.addEventListener("click", (event) => {
      const button = event.target?.closest?.(adapter2.sendSelector);
      if (composer?.contains(button) && enabledSendButton(button, adapter2)) clearAfterSendOrDismiss();
    }, { capture: true, passive: true });
    doc.addEventListener("submit", (event) => {
      if (editor && event.target?.matches?.("form") && event.target.contains(editor)) clearAfterSendOrDismiss();
    }, { capture: true, passive: true });
    doc.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" || event.shiftKey || event.altKey || event.isComposing || event.keyCode === 229 || event.repeat) return;
      if (!editor || !(event.target === editor || editor.contains(event.target))) return;
      pendingEnter = { text: read(), hadStop: stopControlPresent(composer) };
      clearTimeout(enterTimer);
      enterTimer = setTimeout(() => {
        pendingEnter = null;
      }, 2e3);
      setTimeout(reconcile, 0);
    }, { capture: true, passive: true });
    chrome.runtime.onMessage.addListener((message, sender, respond) => {
      if (sender.id !== chrome.runtime.id || message?.type !== "promptprivacy:status") return;
      reconcile();
      respond({ status: editor?.isConnected ? "editor-found" : "editor-not-found", site: adapter2.id });
    });
    storage.local.get({ keywords: [] }).then((value) => {
      keywords = normalizeKeywords(value.keywords);
      lastText = null;
      reconcile();
    });
    storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.keywords) {
        keywords = normalizeKeywords(changes.keywords.newValue);
        pasteReview = null;
        suppressedDraft = null;
        lastText = null;
        reconcile();
      }
    });
    reconcile();
  }

  // src/content/index.js
  var adapter = adapterForOrigin(location.origin);
  if (adapter) startLiveScanner(adapter);
})();
