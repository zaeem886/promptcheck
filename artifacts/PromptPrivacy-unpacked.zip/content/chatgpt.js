(() => {
  // src/shared/detector.js
  var CATEGORY_NAMES = { email: "Email", phone: "Pakistani phone", cnic: "CNIC-like number", apiKey: "API key format", privateKey: "Private key marker", keyword: "Sensitive keyword" };
  var word = /[\p{L}\p{N}_]/u;
  function bounded(text, start, end) {
    return (!text[start - 1] || !word.test(text[start - 1])) && (!text[end] || !word.test(text[end]));
  }
  function normalizeKeywords(input) {
    return [...new Set((Array.isArray(input) ? input : []).filter((x) => typeof x === "string").map((x) => x.trim().toLowerCase()).filter(Boolean))].slice(0, 100).map((x) => x.slice(0, 100));
  }
  function mask(category, value) {
    if (category === "apiKey" || category === "privateKey") return "[credential hidden]";
    if (category === "keyword") return "[keyword hidden]";
    if (category === "email") return `${value[0]}***@***`;
    return `***${value.replace(/\D/g, "").slice(-2)}`;
  }
  function detect(text, keywords = []) {
    const candidates = [];
    const add = (category, pattern, priority, accept = () => true) => {
      for (const m of text.matchAll(pattern)) {
        const start = m.index, end = start + m[0].length;
        if (bounded(text, start, end) && accept(m, start)) candidates.push({ category, start, end, priority, preview: mask(category, m[0]) });
      }
    };
    add("privateKey", /-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----/g, 0);
    add("apiKey", /(?:sk-proj-[A-Za-z0-9_-]{20,200}|sk-[A-Za-z0-9]{20,100}|ghp_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{22,255}|AKIA[A-Z0-9]{16}|AIza[A-Za-z0-9_-]{35})/g, 1);
    add("email", /[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+/g, 2);
    add("cnic", /[1-7]\d{4}-\d{7}-\d/g, 3);
    add("cnic", /[1-7]\d{12}/g, 3, (_m, start) => /(?:cnic|national\s+id)\s*[:#=-]?\s*$/i.test(text.slice(Math.max(0, start - 35), start)));
    add("phone", /(?:\+92[ -]?3\d{2}[ -]?\d{7}|0092[ -]?3\d{2}[ -]?\d{7}|03\d{2}[ -]?\d{7})/g, 4, (_m, start) => {
      return !/(?:order|invoice|reference|tracking)\s*(?:number|no\.?)?\s*[:#=-]?\s*$/i.test(text.slice(Math.max(0, start - 40), start));
    });
    for (const keyword of normalizeKeywords(keywords)) {
      const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      for (const match of text.matchAll(new RegExp(escaped, "giu"))) {
        candidates.push({ category: "keyword", start: match.index, end: match.index + match[0].length, priority: 5, preview: mask("keyword", keyword) });
      }
    }
    candidates.sort((a, b) => a.priority - b.priority || b.end - b.start - (a.end - a.start) || a.start - b.start);
    const accepted = [];
    const occupied = new Uint8Array(text.length);
    for (const candidate of candidates) {
      let overlaps = false;
      for (let i = candidate.start; i < candidate.end; i++) if (occupied[i]) {
        overlaps = true;
        break;
      }
      if (!overlaps) {
        occupied.fill(1, candidate.start, candidate.end);
        accepted.push(candidate);
      }
    }
    return accepted.sort((a, b) => a.start - b.start).map(({ priority, ...finding }) => finding);
  }
  function summarize(findings) {
    return Object.entries(CATEGORY_NAMES).map(([category, label]) => {
      const group = findings.filter((f) => f.category === category);
      return { category, label, count: group.length, previews: [...new Set(group.map((f) => f.preview))].slice(0, 3) };
    }).filter((x) => x.count);
  }

  // src/shared/scan.js
  var DEFAULT_LIMITS = Object.freeze({ maxBytes: 10 * 1024 * 1024, timeoutMs: 15e3, maxTextChars: 2e6, maxPages: 200 });

  // src/content/chatgpt.js
  var SELECTOR = [
    '#prompt-textarea[contenteditable="true"]',
    "textarea#prompt-textarea",
    '[contenteditable="true"][data-testid="prompt-textarea"]',
    // ChatGPT Work composer: observed in the user's live DOM; it has no editor id.
    '[contenteditable="true"][role="textbox"][data-composer-markdown]'
  ].join(", ");
  function startAdapter(doc = document, storage = chrome.storage) {
    let editor = null, host = null, panel = null, timer, keywords = [], lastText = null;
    let draftGroups = null, pasteReview = null;
    function read() {
      return editor ? ("value" in editor ? editor.value : editor.innerText) || "" : "";
    }
    function appendGroups(groups) {
      for (const group of groups) {
        const line = doc.createElement("div");
        line.textContent = `${group.label}: ${group.count} \xB7 ${group.previews.join(", ")}`;
        panel.append(line);
      }
    }
    function render() {
      if (!panel) return;
      panel.replaceChildren();
      if (draftGroups !== null) {
        const title = doc.createElement("strong");
        title.textContent = draftGroups.length ? "PromptPrivacy \xB7 Current draft \xB7 Possible sensitive information" : "PromptPrivacy \xB7 Current draft \xB7 No supported patterns found";
        panel.append(title);
        appendGroups(draftGroups);
      }
      if (pasteReview) {
        const title = doc.createElement("strong");
        title.textContent = `PromptPrivacy \xB7 Pasted text snapshot \xB7 ${pasteReview.partial ? "Partially scanned" : pasteReview.groups.length ? "Findings detected" : "No supported patterns found"}`;
        panel.append(title);
        appendGroups(pasteReview.groups);
        const explanation = doc.createElement("p");
        explanation.textContent = "This reviews the last text pasted into this editor. ChatGPT may convert it into a Pasted text attachment. This snapshot does not track attachment edits, removal, or sending.";
        panel.append(explanation);
        if (pasteReview.partial) {
          const reason = doc.createElement("p");
          reason.textContent = "Only the first 2,000,000 characters were scanned.";
          panel.append(reason);
        }
        const dismiss = doc.createElement("button");
        dismiss.type = "button";
        dismiss.textContent = "Dismiss paste review";
        dismiss.dataset.promptprivacyDismiss = "";
        dismiss.onclick = () => {
          pasteReview = null;
          render();
        };
        panel.append(dismiss);
      }
      if (draftGroups !== null || pasteReview) {
        const note = doc.createElement("p");
        note.textContent = "Advisory only. ChatGPT can access text already typed or pasted here. PromptPrivacy cannot verify when the site transmits it. You control editing and sending.";
        panel.append(note);
      }
    }
    function clear() {
      draftGroups = null;
      render();
    }
    function queue() {
      const text = read();
      if (text === lastText) return;
      lastText = text;
      clearTimeout(timer);
      clear();
      if (!text.trim()) return;
      timer = setTimeout(() => {
        if (!editor?.isConnected || read() !== text) return;
        draftGroups = summarize(detect(text, keywords));
        render();
      }, 300);
    }
    function reconcile() {
      const candidates = [...doc.querySelectorAll(SELECTOR)].filter((x) => x.getClientRects().length && !x.disabled && x.getAttribute("aria-hidden") !== "true");
      const active = candidates.find((x) => x === doc.activeElement || x.contains(doc.activeElement)) || candidates.at(-1) || null;
      if (active !== editor) {
        editor?.removeEventListener("input", queue);
        clearTimeout(timer);
        host?.remove();
        editor = active;
        lastText = null;
        draftGroups = null;
        panel = null;
        if (!editor) return;
        host = doc.createElement("div");
        host.dataset.promptprivacy = "advisory";
        const shadow = host.attachShadow({ mode: "closed" });
        const style = doc.createElement("style");
        style.textContent = ":host{display:block;margin:8px 0;font:12px/1.5 system-ui;color:light-dark(#223548,#e4edf6);color-scheme:light dark}section:not(:empty){border:1px solid #889bae;border-radius:10px;padding:10px 12px;background:light-dark(#f2f7fa,#17232d)}strong{font-size:12px}p{margin:5px 0 0;max-width:680px}";
        panel = doc.createElement("section");
        panel.setAttribute("role", "status");
        panel.setAttribute("aria-live", "polite");
        panel.setAttribute("aria-atomic", "true");
        shadow.append(style, panel);
        const controlsStyle = doc.createElement("style");
        controlsStyle.textContent = "strong{display:block;margin:4px 0}button{font:inherit;margin-top:8px;padding:5px 9px;border:1px solid #889bae;border-radius:6px;background:transparent;color:inherit;cursor:pointer}button:focus-visible{outline:2px solid #c1a15e;outline-offset:2px}";
        shadow.append(controlsStyle);
        (editor.closest("form") || editor.parentElement).after(host);
        editor.addEventListener("input", queue);
      }
      if (editor) queue();
    }
    const observer = new MutationObserver(reconcile);
    observer.observe(doc.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ["contenteditable", "id", "data-testid", "data-composer-markdown", "role", "hidden", "aria-hidden"] });
    doc.addEventListener("focusin", reconcile);
    doc.addEventListener("paste", (event) => {
      reconcile();
      if (!editor || !(event.target === editor || editor.contains(event.target))) return;
      const text = event.clipboardData?.getData("text/plain");
      pasteReview = null;
      if (text?.trim()) {
        pasteReview = {
          groups: summarize(detect(text.slice(0, DEFAULT_LIMITS.maxTextChars), keywords)),
          partial: text.length > DEFAULT_LIMITS.maxTextChars
        };
      }
      render();
    }, true);
    chrome.runtime.onMessage.addListener((message, sender, respond) => {
      if (sender.id !== chrome.runtime.id || message?.type !== "promptprivacy:status") return;
      reconcile();
      respond({ status: editor?.isConnected ? "editor-found" : "editor-not-found" });
    });
    storage.local.get({ keywords: [] }).then((value) => {
      keywords = normalizeKeywords(value.keywords);
      lastText = null;
      reconcile();
    });
    storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.keywords) {
        keywords = normalizeKeywords(changes.keywords.newValue);
        pasteReview = null;
        lastText = null;
        reconcile();
      }
    });
    reconcile();
  }
  startAdapter();
})();
